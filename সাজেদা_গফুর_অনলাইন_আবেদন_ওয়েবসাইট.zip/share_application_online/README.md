# সাজেদা গফুর মডেল মাদরাসা: অনলাইন শেয়ার আবেদন ব্যবস্থা

এটি অনলাইন সিস্টেমের ডেপ্লয়-যোগ্য সোর্স কোড। এতে পাবলিক আবেদন ফর্ম, Firebase Firestore-এ আবেদন সংরক্ষণ, ছবি/NID কপি আপলোড, অ্যাডমিন ই-মেইল/পাসওয়ার্ড লগইন, আবেদন খোঁজা, আবেদন স্ট্যাটাস বদলানো এবং A4 প্রিন্ট/PDF সুবিধা আছে। এটি অফলাইন ফর্ম নয়।

## গুরুত্বপূর্ণ

এই ফোল্ডারটি নিজে থেকে ইন্টারনেটে প্রকাশিত ওয়েবসাইট নয়। চালু করতে আপনার নিজের Firebase project তৈরি করে নিচের একবারের সেটআপ করতে হবে এবং Firebase Hosting-এ deploy করতে হবে। আপনার Firebase project ও ডোমেইনে প্রবেশাধিকার ছাড়া অন্য কেউ আপনার হয়ে সাইটটি প্রকাশ করতে পারে না। Google Sheets ব্যবহার করা হয়নি।

## একবারের সেটআপ

1. https://console.firebase.google.com/ খুলে Google অ্যাকাউন্ট দিয়ে একটি project তৈরি করুন। উদাহরণ project ID: `sgmm-share-apply` (নামটি অন্য কেউ নিয়ে থাকলে ভিন্ন ID দিন)।
2. Project Overview > Add app > Web নির্বাচন করুন। অ্যাপ রেজিস্টার করে Firebase config কপি করুন। `firebase-config.js` খুলে `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`-এর জায়গায় আসল মান বসান।
3. Build > Authentication > Get started > Sign-in method-এ Email/Password চালু করুন।
4. Authentication > Users > Add user থেকে শুধু আপনার অ্যাডমিন ই-মেইল ও শক্তিশালী পাসওয়ার্ড তৈরি করুন। ওয়েবসাইটে কোনো public sign-up নেই। অ্যাডমিন অ্যাকাউন্ট অন্য কাউকে দেবেন না।
5. Build > Firestore Database > Create database করে database তৈরি করুন। তারপর Rules ট্যাবে এই ফোল্ডারের `firestore.rules` ফাইলের নিয়ম কপি করে Publish করুন।
6. Build > Storage > Get started করে Storage চালু করুন। তারপর Rules ট্যাবে `storage.rules`-এর নিয়ম কপি করে Publish করুন। Firebase project-এ billing/Storage availability-এর শর্ত দেখা দিলে Console-এ প্রদর্শিত বর্তমান নির্দেশনা অনুসরণ করুন।
7. কম্পিউটারে Node.js-এর LTS সংস্করণ ইনস্টল করুন: https://nodejs.org/ । এরপর Terminal/Command Prompt খুলে চালান: `npm install -g firebase-tools`
8. এই ফোল্ডারে Terminal খুলে চালান: `firebase login`
9. একই ফোল্ডারে চালান: `firebase use --add` এবং আপনার project নির্বাচন করুন। অথবা `.firebaserc.example` কপি করে `.firebaserc` নাম দিন এবং `YOUR_PROJECT_ID` বদলে আপনার project ID লিখুন।
10. এই ফোল্ডার থেকেই চালান: `firebase deploy`
11. deploy শেষে Firebase একটি Hosting URL দেখাবে, সাধারণত `https://YOUR_PROJECT_ID.web.app`। সেই লিংক আবেদনকারীদের দিন। অ্যাডমিন লগইন হবে `https://YOUR_PROJECT_ID.web.app/admin.html`।

## কীভাবে ব্যবহার করবেন

- আবেদনকারী: ওয়েবসাইটের মূল লিংকে গিয়ে ফর্ম পূরণ করে জমা দেবে।
- আপনি: `/admin.html` খুলে Firebase Authentication-এ তৈরি করা অ্যাডমিন ই-মেইল ও পাসওয়ার্ড দিয়ে লগইন করবেন।
- ড্যাশবোর্ডে নাম, মোবাইল বা আবেদন নম্বর দিয়ে খুঁজবেন; আবেদন খুলে `প্রিন্ট / PDF` চাপবেন।
- `প্রক্রিয়াধীন করুন` দিয়ে আবেদনটির অবস্থা বদলানো যাবে।

## নিরাপত্তা ও অপারেশনাল নোট

- আবেদনকারীরা শুধু নতুন আবেদন জমা দিতে পারে; ডেটাবেজ পড়া, সম্পাদনা ও মুছে ফেলার অনুমতি শুধু লগইন করা ব্যবহারকারীর।
- Firebase config ওয়েব অ্যাপে দেখা যায়—এটি স্বাভাবিক; প্রকৃত সুরক্ষা Firestore/Storage Rules ও Authentication-এর ওপর নির্ভর করে। Rules পরিবর্তন করার সময় সতর্ক থাকুন।
- Public form-এ CAPTCHA/rate-limit নেই; অনেক অজানা ব্যবহারকারী থাকলে অতিরিক্ত abuse protection যোগ করা উচিত।
- প্রিন্টের ফন্ট ও পৃষ্ঠার বিন্যাস ব্রাউজার/প্রিন্টারভেদে সামান্য বদলাতে পারে। প্রিন্ট ডায়ালগে A4 নির্বাচন করুন।
- এই প্রজেক্টে Google Sheets নেই। আবেদন Firestore database-এ থাকে।
